newProjTemplName
================

    Author : Alex Zolotoviski, alex.zolot@here.com

    Created: 00-00-00
    