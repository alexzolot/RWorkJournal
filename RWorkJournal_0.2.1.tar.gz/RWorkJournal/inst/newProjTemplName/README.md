newProjTemplName
================

    Author : Alex Zolotoviski, azolotovitski@medio.com

    Created: 00-00-00
    